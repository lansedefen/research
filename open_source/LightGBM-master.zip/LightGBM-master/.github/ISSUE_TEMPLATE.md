Please search your question on previous issues, [stackoverflow](https://stackoverflow.com/questions/tagged/lightgbm) or other search engines before you open a new one.

For bugs and unexpected issues, please provide following information, so that we could reproduce on our system.

## Environment info
Operating System:
CPU:
C++/Python/R version:

## Error Message:

## Reproducible examples

## Steps to reproduce

1.
2.
3.
