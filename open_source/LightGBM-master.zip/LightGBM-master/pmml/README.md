PMML Generator 
==============

The old python convert script is removed due to it cannot support the new categorical features.

Please move to https://github.com/jpmml/jpmml-lightgbm
